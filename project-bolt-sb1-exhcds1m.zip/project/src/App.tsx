import React from 'react';
import { Routes, Route } from 'react-router-dom';
import Layout from './components/Layout';
import Dashboard from './pages/Dashboard';
import ImportData from './pages/ImportData';
import DataTables from './pages/DataTables';
import Settings from './pages/Settings';
import VehicleTracker from './pages/VehicleTracker';
import NotFound from './pages/NotFound';
import { DataProvider } from './context/DataContext';

function App() {
  return (
    <DataProvider>
      <Layout>
        <Routes>
          <Route path="/" element={<Dashboard />} />
          <Route path="/import" element={<ImportData />} />
          <Route path="/tables" element={<DataTables />} />
          <Route path="/vehicles" element={<VehicleTracker />} />
          <Route path="/settings" element={<Settings />} />
          <Route path="*" element={<NotFound />} />
        </Routes>
      </Layout>
    </DataProvider>
  );
}

export default App