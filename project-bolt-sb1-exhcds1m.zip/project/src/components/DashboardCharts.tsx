import React, { useMemo } from 'react';
import { useData } from '../context/DataContext';
import BarChart from './charts/BarChart';
import PieChart from './charts/PieChart';
import LineChart from './charts/LineChart';
import { AlertCircle } from 'lucide-react';

const DashboardCharts: React.FC = () => {
  const { currentDataset } = useData();

  const chartData = useMemo(() => {
    if (!currentDataset || !currentDataset.rows.length) return null;

    // Get numeric columns for charts
    const numericColumns = currentDataset.columns.filter(column => {
      return currentDataset.rows.some(row => typeof row[column] === 'number');
    });

    if (numericColumns.length === 0) return null;

    // Get categorical columns for grouping
    const categoricalColumns = currentDataset.columns.filter(column => {
      const values = currentDataset.rows.map(row => row[column]);
      const uniqueValues = new Set(values);
      return uniqueValues.size > 1 && uniqueValues.size <= 10 && typeof [...uniqueValues][0] !== 'number';
    });

    // Pick first numeric column for demonstration
    const primaryNumericColumn = numericColumns[0];
    
    // Pick first categorical column for grouping
    const primaryCategoricalColumn = categoricalColumns[0];

    // For bar chart - group by categorical and sum numeric
    let barChartData = null;
    if (primaryCategoricalColumn && primaryNumericColumn) {
      const groupedData: Record<string, number> = {};
      
      currentDataset.rows.forEach(row => {
        const category = String(row[primaryCategoricalColumn] || 'Unknown');
        const value = Number(row[primaryNumericColumn]) || 0;
        
        groupedData[category] = (groupedData[category] || 0) + value;
      });
      
      const labels = Object.keys(groupedData);
      const data = labels.map(label => groupedData[label]);
      
      barChartData = {
        labels,
        datasets: [
          {
            label: primaryNumericColumn,
            data,
            backgroundColor: 'rgba(59, 130, 246, 0.7)',
          }
        ]
      };
    }

    // For pie chart - distribution of categorical column
    let pieChartData = null;
    if (primaryCategoricalColumn) {
      const distribution: Record<string, number> = {};
      
      currentDataset.rows.forEach(row => {
        const category = String(row[primaryCategoricalColumn] || 'Unknown');
        distribution[category] = (distribution[category] || 0) + 1;
      });
      
      const labels = Object.keys(distribution);
      const data = labels.map(label => distribution[label]);
      
      const backgroundColors = [
        'rgba(59, 130, 246, 0.7)',
        'rgba(16, 185, 129, 0.7)',
        'rgba(245, 158, 11, 0.7)',
        'rgba(239, 68, 68, 0.7)',
        'rgba(168, 85, 247, 0.7)',
        'rgba(236, 72, 153, 0.7)',
        'rgba(251, 146, 60, 0.7)',
        'rgba(20, 184, 166, 0.7)',
        'rgba(99, 102, 241, 0.7)',
        'rgba(124, 58, 237, 0.7)',
      ];
      
      pieChartData = {
        labels,
        data,
        backgroundColor: backgroundColors.slice(0, labels.length),
      };
    }

    // For line chart - if dataset has any date columns
    let lineChartData = null;
    const dateColumn = currentDataset.columns.find(column => {
      return currentDataset.rows.some(row => {
        const value = row[column];
        return value instanceof Date || (typeof value === 'string' && !isNaN(Date.parse(value)));
      });
    });

    if (dateColumn && primaryNumericColumn) {
      // Sort by date
      const sortedRows = [...currentDataset.rows].sort((a, b) => {
        const dateA = new Date(a[dateColumn]);
        const dateB = new Date(b[dateColumn]);
        return dateA.getTime() - dateB.getTime();
      });
      
      // Group by date and calculate average
      const dateGroups: Record<string, { sum: number; count: number }> = {};
      
      sortedRows.forEach(row => {
        if (!row[dateColumn]) return;
        
        const date = new Date(row[dateColumn]);
        // Add validation check for date
        if (!(date instanceof Date) || isNaN(date.getTime())) return;
        
        const dateString = date.toISOString().split('T')[0];
        const value = Number(row[primaryNumericColumn]) || 0;
        
        if (!dateGroups[dateString]) {
          dateGroups[dateString] = { sum: 0, count: 0 };
        }
        
        dateGroups[dateString].sum += value;
        dateGroups[dateString].count += 1;
      });
      
      const dates = Object.keys(dateGroups).sort();
      const values = dates.map(date => dateGroups[date].sum / dateGroups[date].count);
      
      lineChartData = {
        labels: dates,
        datasets: [
          {
            label: primaryNumericColumn,
            data: values,
            borderColor: 'rgba(59, 130, 246, 0.8)',
            backgroundColor: 'rgba(59, 130, 246, 0.2)',
          }
        ]
      };
    }

    return {
      barChart: barChartData,
      pieChart: pieChartData,
      lineChart: lineChartData,
    };
  }, [currentDataset]);

  if (!currentDataset) {
    return (
      <div className="text-center py-8">
        <p className="text-gray-500">No dataset selected. Please select a dataset to view charts.</p>
      </div>
    );
  }

  if (!chartData) {
    return (
      <div className="card text-center py-8">
        <AlertCircle className="h-12 w-12 text-accent-500 mx-auto mb-4" />
        <h3 className="text-lg font-medium text-gray-900 mb-2">Unable to Generate Charts</h3>
        <p className="text-gray-500 max-w-md mx-auto">
          The current dataset doesn't contain suitable numeric or categorical data for visualization.
          Please select a different dataset with numeric columns.
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      {/* Two charts in one row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {chartData.barChart && (
          <div className="card">
            <BarChart 
              title={`Sum of Values by Category`}
              labels={chartData.barChart.labels}
              datasets={chartData.barChart.datasets}
              height={300}
            />
          </div>
        )}
        
        {chartData.pieChart && (
          <div className="card">
            <PieChart 
              title="Distribution by Category"
              labels={chartData.pieChart.labels}
              data={chartData.pieChart.data}
              backgroundColor={chartData.pieChart.backgroundColor}
              height={300}
            />
          </div>
        )}
      </div>
      
      {/* Full width chart */}
      {chartData.lineChart && (
        <div className="card">
          <LineChart 
            title="Data Trend Over Time"
            labels={chartData.lineChart.labels}
            datasets={chartData.lineChart.datasets}
            height={300}
          />
        </div>
      )}
    </div>
  );
};

export default DashboardCharts;