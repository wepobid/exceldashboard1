import React from 'react';
import { useData, Dataset } from '../context/DataContext';
import { FileText, Trash2, ExternalLink, BarChart2 } from 'lucide-react';
import { formatDistanceToNow } from '../utils/dateUtils';
import { useNavigate } from 'react-router-dom';

const DatasetList: React.FC = () => {
  const { datasets, removeDataset, setCurrentDataset, currentDataset } = useData();
  const navigate = useNavigate();

  const handleRemoveDataset = async (e: React.MouseEvent, id: string) => {
    e.stopPropagation();
    if (window.confirm('Are you sure you want to delete this dataset?')) {
      await removeDataset(id);
    }
  };

  const handleSelectDataset = async (id: string) => {
    await setCurrentDataset(id);
  };

  const handleViewData = async (e: React.MouseEvent, id: string) => {
    e.stopPropagation();
    await setCurrentDataset(id);
    navigate('/tables');
  };

  const handleViewDashboard = async (e: React.MouseEvent, id: string) => {
    e.stopPropagation();
    await setCurrentDataset(id);
    navigate('/');
  };

  if (datasets.length === 0) {
    return (
      <div className="text-center py-8">
        <p className="text-gray-500">No datasets found. Import data to get started.</p>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
      {datasets.map((dataset) => (
        <div
          key={dataset.id}
          className={`card cursor-pointer transition-all hover:shadow-lg ${
            currentDataset?.id === dataset.id ? 'ring-2 ring-primary-500' : ''
          }`}
          onClick={() => handleSelectDataset(dataset.id)}
        >
          <div className="flex justify-between items-start">
            <div className="flex items-center">
              <FileText className="h-6 w-6 text-primary-500 mr-2" />
              <h3 className="text-lg font-medium text-gray-900 truncate" title={dataset.name}>
                {dataset.name}
              </h3>
            </div>
            <button
              onClick={(e) => handleRemoveDataset(e, dataset.id)}
              className="text-gray-400 hover:text-error-500 transition-colors p-1"
              title="Delete dataset"
            >
              <Trash2 className="h-5 w-5" />
            </button>
          </div>
          
          <div className="mt-4 space-y-3">
            <div className="flex items-baseline justify-between">
              <span className="text-sm text-gray-500">Created</span>
              <span className="text-sm text-gray-700">
                {formatDistanceToNow(dataset.createdAt)}
              </span>
            </div>
            
            <div className="flex items-baseline justify-between">
              <span className="text-sm text-gray-500">Rows</span>
              <span className="text-sm text-gray-700">{dataset.rows.length}</span>
            </div>
            
            <div className="flex items-baseline justify-between">
              <span className="text-sm text-gray-500">Columns</span>
              <span className="text-sm text-gray-700">{dataset.columns.length}</span>
            </div>
          </div>
          
          <div className="mt-6 flex justify-between">
            <button 
              className="btn-outline text-xs flex items-center"
              onClick={(e) => handleViewData(e, dataset.id)}
            >
              <ExternalLink className="h-4 w-4 mr-1" />
              View Data
            </button>
            
            <button 
              className="btn-primary text-xs flex items-center"
              onClick={(e) => handleViewDashboard(e, dataset.id)}
            >
              <BarChart2 className="h-4 w-4 mr-1" />
              Dashboard
            </button>
          </div>
        </div>
      ))}
    </div>
  );
};

export default DatasetList;