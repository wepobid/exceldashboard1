import React, { useCallback, useState } from 'react';
import { useDropzone } from 'react-dropzone';
import { UploadCloud, AlertCircle, CheckCircle, XCircle } from 'lucide-react';
import { parseExcelFile } from '../services/excelParser';
import { useData } from '../context/DataContext';

const FileUploader: React.FC = () => {
  const { addDataset } = useData();
  const [fileStatus, setFileStatus] = useState<{
    status: 'idle' | 'uploading' | 'success' | 'error';
    message: string;
  }>({
    status: 'idle',
    message: '',
  });

  const onDrop = useCallback(
    async (acceptedFiles: File[]) => {
      if (acceptedFiles.length === 0) return;

      const file = acceptedFiles[0];
      
      // Check if it's an Excel file
      if (!file.name.match(/\.(xlsx|xls|csv)$/)) {
        setFileStatus({
          status: 'error',
          message: 'Please upload a valid Excel or CSV file',
        });
        return;
      }
      
      try {
        setFileStatus({
          status: 'uploading',
          message: 'Processing file...',
        });
        
        const dataset = await parseExcelFile(file);
        await addDataset(dataset);
        
        setFileStatus({
          status: 'success',
          message: `Successfully imported ${dataset.rows.length} rows from "${file.name}"`,
        });
        
        // Reset status after 5 seconds
        setTimeout(() => {
          setFileStatus({
            status: 'idle',
            message: '',
          });
        }, 5000);
      } catch (error) {
        setFileStatus({
          status: 'error',
          message: `Error: ${(error as Error).message || 'Failed to import file'}`,
        });
      }
    },
    [addDataset]
  );

  const { getRootProps, getInputProps, isDragActive } = useDropzone({ onDrop });

  return (
    <div className="mb-8">
      <div
        {...getRootProps()}
        className={`border-2 border-dashed rounded-lg p-8 text-center transition-colors cursor-pointer
          ${isDragActive ? 'border-primary-400 bg-primary-50' : 'border-gray-300 hover:border-primary-300 hover:bg-gray-50'}
          ${fileStatus.status === 'error' ? 'border-error-500 bg-error-50' : ''}
          ${fileStatus.status === 'success' ? 'border-success-500 bg-success-50' : ''}
        `}
      >
        <input {...getInputProps()} />
        
        <div className="flex flex-col items-center space-y-4">
          {fileStatus.status === 'idle' && (
            <>
              <UploadCloud className="h-12 w-12 text-gray-400" />
              <div>
                <p className="text-lg font-medium text-gray-700">
                  {isDragActive ? 'Drop the file here' : 'Drag and drop an Excel file here'}
                </p>
                <p className="text-sm text-gray-500 mt-1">or click to browse</p>
              </div>
              <p className="text-xs text-gray-400">
                Supports Excel files (.xlsx, .xls) and CSV files
              </p>
            </>
          )}
          
          {fileStatus.status === 'uploading' && (
            <>
              <div className="animate-pulse">
                <UploadCloud className="h-12 w-12 text-primary-400" />
              </div>
              <p className="text-lg font-medium text-primary-700">{fileStatus.message}</p>
            </>
          )}
          
          {fileStatus.status === 'success' && (
            <>
              <CheckCircle className="h-12 w-12 text-success-500" />
              <p className="text-lg font-medium text-success-700">{fileStatus.message}</p>
              <button 
                className="btn-primary mt-2"
                onClick={(e) => {
                  e.stopPropagation();
                  setFileStatus({ status: 'idle', message: '' });
                }}
              >
                Upload Another File
              </button>
            </>
          )}
          
          {fileStatus.status === 'error' && (
            <>
              <AlertCircle className="h-12 w-12 text-error-500" />
              <p className="text-lg font-medium text-error-700">{fileStatus.message}</p>
              <button 
                className="btn-outline mt-2"
                onClick={(e) => {
                  e.stopPropagation();
                  setFileStatus({ status: 'idle', message: '' });
                }}
              >
                Try Again
              </button>
            </>
          )}
        </div>
      </div>
    </div>
  );
};

export default FileUploader;