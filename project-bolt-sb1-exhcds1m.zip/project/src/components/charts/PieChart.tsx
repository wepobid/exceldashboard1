import React from 'react';
import { Chart as ChartJS, ArcElement, Tooltip, Legend } from 'chart.js';
import { Pie } from 'react-chartjs-2';

ChartJS.register(ArcElement, Tooltip, Legend);

interface PieChartProps {
  title: string;
  labels: string[];
  data: number[];
  backgroundColor: string[];
  height?: number;
}

const PieChart: React.FC<PieChartProps> = ({
  title,
  labels,
  data,
  backgroundColor,
  height = 300,
}) => {
  const options = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        position: 'right' as const,
        labels: {
          padding: 20,
          font: {
            size: 12,
          },
        },
      },
      title: {
        display: true,
        text: title,
        font: {
          size: 16,
        },
      },
      tooltip: {
        backgroundColor: 'rgba(33, 37, 41, 0.9)',
        titleFont: {
          size: 14,
        },
        bodyFont: {
          size: 13,
        },
        padding: 10,
        cornerRadius: 4,
      },
    },
    animation: {
      animateRotate: true,
      animateScale: true,
    },
  };

  const chartData = {
    labels,
    datasets: [
      {
        data,
        backgroundColor,
        borderColor: 'white',
        borderWidth: 2,
        hoverOffset: 10,
      },
    ],
  };

  return (
    <div style={{ height }}>
      <Pie options={options} data={chartData} />
    </div>
  );
};

export default PieChart;