import React, { createContext, useState, useContext, useEffect } from 'react';
import { db } from '../services/db';

interface SheetData {
  name: string;
  columns: string[];
  rows: Record<string, any>[];
}

interface DataContextType {
  datasets: Dataset[];
  currentDataset: Dataset | null;
  loading: boolean;
  error: string | null;
  addDataset: (dataset: Omit<Dataset, 'id'>) => Promise<void>;
  removeDataset: (id: string) => Promise<void>;
  setCurrentDataset: (id: string | null) => Promise<void>;
  setCurrentSheet: (sheetName: string) => void;
}

export interface Dataset {
  id: string;
  name: string;
  createdAt: Date;
  sheets: SheetData[];
  currentSheet: string;
  columns: string[];
  rows: Record<string, any>[];
  summary?: {
    totalSheets: number;
    totalRows: number;
    totalColumns: number;
    hasHeaders: boolean;
  };
}

const DataContext = createContext<DataContextType | undefined>(undefined);

export const DataProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [datasets, setDatasets] = useState<Dataset[]>([]);
  const [currentDataset, setCurrentDatasetState] = useState<Dataset | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const loadData = async () => {
      try {
        setLoading(true);
        const loadedDatasets = await db.datasets.toArray();
        setDatasets(loadedDatasets);
        
        const lastId = localStorage.getItem('currentDatasetId');
        if (lastId) {
          const dataset = loadedDatasets.find(d => d.id === lastId) || null;
          setCurrentDatasetState(dataset);
        }
        
        setLoading(false);
      } catch (err) {
        setError('Failed to load data from database');
        setLoading(false);
        console.error('Error loading data:', err);
      }
    };
    
    loadData();
  }, []);

  const addDataset = async (dataset: Omit<Dataset, 'id'>) => {
    try {
      setLoading(true);
      // Generate a unique ID using crypto.randomUUID()
      const newDataset: Dataset = {
        ...dataset,
        id: crypto.randomUUID()
      };
      
      await db.datasets.add(newDataset);
      setDatasets(prev => [...prev, newDataset]);
      setLoading(false);
    } catch (err) {
      setError('Failed to add dataset');
      setLoading(false);
      console.error('Error adding dataset:', err);
    }
  };

  const removeDataset = async (id: string) => {
    try {
      setLoading(true);
      await db.datasets.delete(id);
      setDatasets(prev => prev.filter(dataset => dataset.id !== id));
      
      if (currentDataset?.id === id) {
        setCurrentDatasetState(null);
        localStorage.removeItem('currentDatasetId');
      }
      
      setLoading(false);
    } catch (err) {
      setError('Failed to remove dataset');
      setLoading(false);
      console.error('Error removing dataset:', err);
    }
  };

  const setCurrentDataset = async (id: string | null) => {
    if (!id) {
      setCurrentDatasetState(null);
      localStorage.removeItem('currentDatasetId');
      return;
    }
    
    const dataset = datasets.find(d => d.id === id) || null;
    setCurrentDatasetState(dataset);
    
    if (dataset) {
      localStorage.setItem('currentDatasetId', id);
    } else {
      localStorage.removeItem('currentDatasetId');
    }
  };

  const setCurrentSheet = (sheetName: string) => {
    if (!currentDataset) return;

    const sheet = currentDataset.sheets.find(s => s.name === sheetName);
    if (!sheet) return;

    setCurrentDatasetState({
      ...currentDataset,
      currentSheet: sheetName,
      columns: sheet.columns,
      rows: sheet.rows
    });
  };

  return (
    <DataContext.Provider
      value={{
        datasets,
        currentDataset,
        loading,
        error,
        addDataset,
        removeDataset,
        setCurrentDataset,
        setCurrentSheet,
      }}
    >
      {children}
    </DataContext.Provider>
  );
};

export const useData = () => {
  const context = useContext(DataContext);
  if (context === undefined) {
    throw new Error('useData must be used within a DataProvider');
  }
  return context;
};