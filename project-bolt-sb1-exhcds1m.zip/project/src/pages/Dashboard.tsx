import React from 'react';
import { useData } from '../context/DataContext';
import DashboardCharts from '../components/DashboardCharts';
import { Database, UploadCloud } from 'lucide-react';
import { Link } from 'react-router-dom';

const Dashboard: React.FC = () => {
  const { datasets, currentDataset } = useData();

  // Empty state when no datasets exist
  if (datasets.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-16">
        <div className="text-center max-w-md">
          <div className="bg-primary-100 rounded-full p-4 inline-block mb-4">
            <UploadCloud className="h-8 w-8 text-primary-600" />
          </div>
          <h2 className="text-2xl font-bold text-gray-900 mb-2">No datasets found</h2>
          <p className="text-gray-500 mb-8">
            Upload an Excel file to visualize your data and create interactive dashboards.
          </p>
          <Link to="/import" className="btn-primary">
            Import Data
          </Link>
        </div>
      </div>
    );
  }

  // Display dataset selector if no dataset is selected
  if (!currentDataset) {
    return (
      <div className="flex flex-col items-center justify-center py-16">
        <div className="text-center max-w-md">
          <div className="bg-accent-100 rounded-full p-4 inline-block mb-4">
            <Database className="h-8 w-8 text-accent-600" />
          </div>
          <h2 className="text-2xl font-bold text-gray-900 mb-2">Select a dataset</h2>
          <p className="text-gray-500 mb-8">
            You have {datasets.length} dataset{datasets.length !== 1 ? 's' : ''}. Select one to view visualizations.
          </p>
          <Link to="/tables" className="btn-primary">
            View Datasets
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div>
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-8">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Dashboard</h1>
          <p className="text-gray-500 mt-1">
            Visualizing data from "{currentDataset.name}"
          </p>
        </div>
        <div className="mt-4 sm:mt-0 flex space-x-4">
          <Link to="/tables" className="btn-outline">
            View Data Tables
          </Link>
          <Link to="/import" className="btn-primary">
            Import New Data
          </Link>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <div className="card bg-primary-50 border border-primary-100">
          <h3 className="text-lg font-medium text-primary-900 mb-2">Total Rows</h3>
          <p className="text-3xl font-bold text-primary-700">{currentDataset.rows.length}</p>
        </div>
        
        <div className="card bg-secondary-50 border border-secondary-100">
          <h3 className="text-lg font-medium text-secondary-900 mb-2">Total Columns</h3>
          <p className="text-3xl font-bold text-secondary-700">{currentDataset.columns.length}</p>
        </div>
        
        <div className="card bg-accent-50 border border-accent-100">
          <h3 className="text-lg font-medium text-accent-900 mb-2">Last Updated</h3>
          <p className="text-3xl font-bold text-accent-700">
            {new Date(currentDataset.createdAt).toLocaleDateString()}
          </p>
        </div>
      </div>

      <DashboardCharts />
    </div>
  );
};

export default Dashboard;