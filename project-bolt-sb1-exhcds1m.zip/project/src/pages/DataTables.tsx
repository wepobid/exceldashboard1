import React from 'react';
import DataTable from '../components/DataTable';
import DatasetList from '../components/DatasetList';
import { useData } from '../context/DataContext';
import { Download } from 'lucide-react';
import { exportToExcel } from '../services/excelParser';

const DataTables: React.FC = () => {
  const { currentDataset } = useData();
  
  const handleExport = () => {
    if (currentDataset) {
      exportToExcel(currentDataset);
    }
  };

  return (
    <div>
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-8">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Data Tables</h1>
          <p className="text-gray-500 mt-1">
            View and manage your imported datasets
          </p>
        </div>
        
        {currentDataset && (
          <button 
            className="btn-outline mt-4 sm:mt-0 flex items-center"
            onClick={handleExport}
          >
            <Download className="h-4 w-4 mr-2" />
            Export to Excel
          </button>
        )}
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-1">
          <div className="card">
            <h2 className="text-lg font-medium text-gray-900 mb-4">Select Dataset</h2>
            <DatasetList />
          </div>
        </div>
        
        <div className="lg:col-span-2">
          <DataTable />
        </div>
      </div>
    </div>
  );
};

export default DataTables;