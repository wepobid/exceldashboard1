import React from 'react';
import FileUploader from '../components/FileUploader';
import DatasetList from '../components/DatasetList';

const ImportData: React.FC = () => {
  return (
    <div>
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-gray-900">Import Data</h1>
        <p className="text-gray-500 mt-1">
          Upload Excel files to visualize and analyze your data
        </p>
      </div>
      
      <FileUploader />
      
      <div className="mb-6">
        <h2 className="text-xl font-semibold text-gray-900 mb-4">Your Datasets</h2>
        <DatasetList />
      </div>
    </div>
  );
};

export default ImportData;