import React, { useState } from 'react';
import { useData } from '../context/DataContext';
import { db } from '../services/db';
import { AlertCircle, Save, Trash2 } from 'lucide-react';

const Settings: React.FC = () => {
  const { datasets, loading } = useData();
  const [confirmClear, setConfirmClear] = useState(false);
  const [clearSuccess, setClearSuccess] = useState(false);
  
  const handleClearAllData = async () => {
    try {
      await db.delete();
      setConfirmClear(false);
      setClearSuccess(true);
      
      // Reload the page after 2 seconds
      setTimeout(() => {
        window.location.reload();
      }, 2000);
    } catch (error) {
      console.error('Error clearing database:', error);
    }
  };

  return (
    <div>
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-gray-900">Settings</h1>
        <p className="text-gray-500 mt-1">
          Manage your application preferences and data
        </p>
      </div>
      
      <div className="grid grid-cols-1 gap-8">
        {/* Database Information */}
        <div className="card">
          <h2 className="text-lg font-medium text-gray-900 mb-4">Database Information</h2>
          
          <div className="space-y-4">
            <div className="flex items-baseline justify-between">
              <span className="text-gray-600">Database Type</span>
              <span className="font-medium">IndexedDB (Browser Storage)</span>
            </div>
            
            <div className="flex items-baseline justify-between">
              <span className="text-gray-600">Total Datasets</span>
              <span className="font-medium">{loading ? '...' : datasets.length}</span>
            </div>
            
            <div className="flex items-baseline justify-between">
              <span className="text-gray-600">Total Rows</span>
              <span className="font-medium">
                {loading ? '...' : datasets.reduce((total, dataset) => total + dataset.rows.length, 0)}
              </span>
            </div>
            
            <div className="border-t border-gray-200 pt-4 mt-4">
              <p className="text-sm text-gray-500 mb-4">
                Your data is stored locally in your browser using IndexedDB. It will persist between visits
                but can be cleared at any time.
              </p>
              
              {!confirmClear && !clearSuccess && (
                <button 
                  className="btn bg-error-500 text-white hover:bg-error-600 focus:ring-error-400 flex items-center"
                  onClick={() => setConfirmClear(true)}
                >
                  <Trash2 className="h-4 w-4 mr-2" />
                  Clear All Data
                </button>
              )}
              
              {confirmClear && (
                <div className="bg-error-50 border border-error-200 rounded-md p-4">
                  <div className="flex items-start">
                    <AlertCircle className="h-5 w-5 text-error-500 mt-0.5 mr-3" />
                    <div>
                      <h3 className="text-error-700 font-medium mb-2">Confirm Data Deletion</h3>
                      <p className="text-error-600 text-sm mb-4">
                        This will permanently delete all your datasets and cannot be undone.
                        Are you sure you want to proceed?
                      </p>
                      <div className="flex space-x-4">
                        <button 
                          className="btn bg-error-500 text-white hover:bg-error-600 focus:ring-error-400"
                          onClick={handleClearAllData}
                        >
                          Yes, Delete Everything
                        </button>
                        <button 
                          className="btn-outline"
                          onClick={() => setConfirmClear(false)}
                        >
                          Cancel
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              )}
              
              {clearSuccess && (
                <div className="bg-success-50 border border-success-200 rounded-md p-4">
                  <p className="text-success-700">
                    All data has been successfully cleared. The page will reload momentarily.
                  </p>
                </div>
              )}
            </div>
          </div>
        </div>
        
        {/* Application Preferences */}
        <div className="card">
          <h2 className="text-lg font-medium text-gray-900 mb-4">Application Preferences</h2>
          
          <form className="space-y-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Application Name
              </label>
              <input
                type="text"
                className="input"
                defaultValue="DataVision"
                placeholder="Enter application name"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Default Rows Per Page
              </label>
              <select className="input">
                <option value="10">10 rows</option>
                <option value="25">25 rows</option>
                <option value="50">50 rows</option>
                <option value="100">100 rows</option>
              </select>
            </div>
            
            <div className="flex items-center">
              <input
                id="auto-chart"
                type="checkbox"
                className="h-4 w-4 text-primary-600 border-gray-300 rounded focus:ring-primary-500"
                defaultChecked
              />
              <label htmlFor="auto-chart" className="ml-2 block text-sm text-gray-700">
                Automatically generate charts for imported data
              </label>
            </div>
            
            <div>
              <button type="button" className="btn-primary flex items-center">
                <Save className="h-4 w-4 mr-2" />
                Save Preferences
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default Settings;