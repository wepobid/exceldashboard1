import React, { useState, useEffect } from 'react';
import { useData } from '../context/DataContext';
import { Fuel, Car } from 'lucide-react';
import { db, VehicleData } from '../services/db';

const VehicleTracker: React.FC = () => {
  const { currentDataset } = useData();
  const [selectedVehicle, setSelectedVehicle] = useState<string>('');
  const [vehicleData, setVehicleData] = useState<VehicleData[]>([]);
  const [vehicles, setVehicles] = useState<string[]>([]);
  const [totals, setTotals] = useState({
    distance: 0,
    fuelAmount: 0,
    totalCost: 0,
    avgCostPerLiter: 0,
    avgKmPerLiter: 0,
    avgCostPerKm: 0,
  });

  // Load vehicles from database
  useEffect(() => {
    const loadVehicles = async () => {
      const allData = await db.vehicleData.toArray();
      const uniqueVehicles = [...new Set(allData.map(data => data.vehicle))].sort();
      setVehicles(uniqueVehicles);
    };
    loadVehicles();
  }, []);

  // Load vehicle data when selection changes
  useEffect(() => {
    const loadVehicleData = async () => {
      if (!selectedVehicle) return;

      const data = await db.vehicleData
        .where('vehicle')
        .equals(selectedVehicle)
        .toArray();

      setVehicleData(data);

      // Calculate totals
      const newTotals = data.reduce(
        (acc, curr) => ({
          distance: acc.distance + curr.distance,
          fuelAmount: acc.fuelAmount + curr.fuelAmount,
          totalCost: acc.totalCost + curr.totalCost,
          avgCostPerLiter: acc.avgCostPerLiter + curr.costPerLiter,
          avgKmPerLiter: acc.avgKmPerLiter + curr.kmPerLiter,
          avgCostPerKm: acc.avgCostPerKm + curr.costPerKm,
        }),
        { distance: 0, fuelAmount: 0, totalCost: 0, avgCostPerLiter: 0, avgKmPerLiter: 0, avgCostPerKm: 0 }
      );

      const monthCount = data.length;
      setTotals({
        ...newTotals,
        avgCostPerLiter: newTotals.avgCostPerLiter / monthCount,
        avgKmPerLiter: newTotals.avgKmPerLiter / monthCount,
        avgCostPerKm: newTotals.avgCostPerKm / monthCount,
      });
    };

    loadVehicleData();
  }, [selectedVehicle]);

  return (
    <div>
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-8">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Vehicle Gas Tracker</h1>
          <p className="text-gray-500 mt-1">
            Monitor fuel consumption and costs for your vehicle fleet
          </p>
        </div>
      </div>

      <div className="card mb-6">
        <div className="flex items-center gap-4">
          <Car className="h-6 w-6 text-primary-500" />
          <select
            className="input flex-1"
            value={selectedVehicle}
            onChange={(e) => setSelectedVehicle(e.target.value)}
          >
            <option value="">Select a vehicle</option>
            {vehicles.map((vehicle) => (
              <option key={vehicle} value={vehicle}>
                {vehicle}
              </option>
            ))}
          </select>
        </div>
      </div>

      {selectedVehicle && (
        <>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            <div className="card bg-primary-50 border border-primary-100">
              <Fuel className="h-6 w-6 text-primary-500 mb-2" />
              <h3 className="text-lg font-medium text-primary-900 mb-2">Total Distance</h3>
              <p className="text-3xl font-bold text-primary-700">{totals.distance.toFixed(2)} km</p>
            </div>
            
            <div className="card bg-secondary-50 border border-secondary-100">
              <h3 className="text-lg font-medium text-secondary-900 mb-2">Total Fuel</h3>
              <p className="text-3xl font-bold text-secondary-700">{totals.fuelAmount.toFixed(2)} L</p>
            </div>
            
            <div className="card bg-accent-50 border border-accent-100">
              <h3 className="text-lg font-medium text-accent-900 mb-2">Total Cost</h3>
              <p className="text-3xl font-bold text-accent-700">{totals.totalCost.toFixed(2)} RON</p>
            </div>
          </div>

          <div className="card overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Month</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Distance (km)</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Fuel (L)</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Cost (RON)</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">RON/L</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">km/L</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">RON/km</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Working Hours</th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {vehicleData.map((data, index) => (
                  <tr key={index} className="hover:bg-gray-50">
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{data.month}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{data.distance.toFixed(2)}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{data.fuelAmount.toFixed(2)}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{data.totalCost.toFixed(2)}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{data.costPerLiter.toFixed(2)}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{data.kmPerLiter.toFixed(2)}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{data.costPerKm.toFixed(2)}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{data.workingHours}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </>
      )}
    </div>
  );
};

export default VehicleTracker;