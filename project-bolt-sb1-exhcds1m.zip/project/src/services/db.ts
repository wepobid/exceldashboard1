import Dexie, { Table } from 'dexie';
import { Dataset } from '../context/DataContext';

export interface VehicleData {
  id?: number;
  vehicle: string;
  month: string;
  distance: number;
  fuelAmount: number;
  totalCost: number;
  costPerLiter: number;
  kmPerLiter: number;
  costPerKm: number;
  parkingHours: number;
  workingHours: number;
}

class DataDB extends Dexie {
  datasets!: Table<Dataset, string>;
  vehicleData!: Table<VehicleData, number>;

  constructor() {
    super('DataVisionDB');
    this.version(2).stores({
      datasets: '++id, name, createdAt',
      vehicleData: '++id, vehicle, month'
    });
  }
}

export const db = new DataDB();