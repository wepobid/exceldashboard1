import * as XLSX from 'xlsx';
import { Dataset } from '../context/DataContext';
import { db, VehicleData } from './db';

interface SheetData {
  name: string;
  columns: string[];
  rows: Record<string, any>[];
}

const processVehicleData = async (rows: Record<string, any>[]) => {
  // Clear existing vehicle data
  await db.vehicleData.clear();

  // Process and store vehicle data
  const vehicleData: VehicleData[] = rows.map(row => ({
    vehicle: row.VEHICUL || '',
    month: row.LUNA || '',
    distance: Number(row['DIST PARC KM']) || 0,
    fuelAmount: Number(row['ALIM. LITRI']) || 0,
    totalCost: Number(row['TOTAL FUEL COST']) || 0,
    costPerLiter: Number(row['COST/L']) || 0,
    kmPerLiter: Number(row['KM/LITRU']) || 0,
    costPerKm: Number(row['COST/KM']) || 0,
    parkingHours: Number(row['FOI PARC.']) || 0,
    workingHours: Number(row['CONS/H']) || 0
  }));

  // Bulk add vehicle data
  await db.vehicleData.bulkAdd(vehicleData);
};

export const parseExcelFile = (file: File): Promise<Omit<Dataset, 'id'>> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    
    reader.onload = async (e) => {
      try {
        const data = e.target?.result;
        const workbook = XLSX.read(data, { type: 'binary' });
        
        // Process all sheets
        const sheets: SheetData[] = workbook.SheetNames.map(sheetName => {
          const worksheet = workbook.Sheets[sheetName];
          const jsonData = XLSX.utils.sheet_to_json(worksheet, { header: 1 });
          
          if (!jsonData || jsonData.length === 0) {
            return {
              name: sheetName,
              columns: [],
              rows: []
            };
          }
          
          // Extract headers (first row) and data
          const headers = (jsonData[0] as string[]).map(header => 
            header ? header.toString().trim() : `Column_${Math.random().toString(36).substr(2, 9)}`
          );
          
          const rows = jsonData.slice(1).map(row => {
            const rowData: Record<string, any> = {};
            (row as any[]).forEach((cell, index) => {
              rowData[headers[index]] = cell;
            });
            return rowData;
          });
          
          return {
            name: sheetName,
            columns: headers,
            rows: rows
          };
        });

        // If this is the Centralizator file, process vehicle data
        if (file.name.toLowerCase().includes('centralizator')) {
          const centralizatorSheet = sheets.find(s => s.name === "Centralizator 2025");
          if (centralizatorSheet) {
            await processVehicleData(centralizatorSheet.rows);
          }
        }
        
        // Create dataset object
        const dataset: Omit<Dataset, 'id'> = {
          name: file.name.replace(/\.[^/.]+$/, ""),
          createdAt: new Date(),
          sheets: sheets,
          currentSheet: sheets[0]?.name || '',
          columns: sheets[0]?.columns || [],
          rows: sheets[0]?.rows || [],
          summary: {
            totalSheets: sheets.length,
            totalRows: sheets.reduce((sum, sheet) => sum + sheet.rows.length, 0),
            totalColumns: sheets.reduce((sum, sheet) => sum + sheet.columns.length, 0),
            hasHeaders: true
          }
        };
        
        resolve(dataset);
      } catch (error) {
        reject(new Error('Failed to parse Excel file'));
      }
    };
    
    reader.onerror = () => {
      reject(new Error('Failed to read file'));
    };
    
    reader.readAsBinaryString(file);
  });
};

export const exportToExcel = (dataset: Dataset): void => {
  const wb = XLSX.utils.book_new();
  
  // Export all sheets
  dataset.sheets?.forEach(sheet => {
    const data = [
      sheet.columns,
      ...sheet.rows.map(row => sheet.columns.map(col => row[col]))
    ];
    const ws = XLSX.utils.aoa_to_sheet(data);
    XLSX.utils.book_append_sheet(wb, ws, sheet.name);
  });
  
  XLSX.writeFile(wb, `${dataset.name}-export.xlsx`);
};